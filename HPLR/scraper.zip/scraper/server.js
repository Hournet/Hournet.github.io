const puppeteer = require('puppeteer');
const http = require('http');
const url = require('url');
const fs = require('fs');

let browser;
let page;

// Функция для запуска браузера и страницы
const initializeBrowser = async () => {
  if (!browser) {
    browser = await puppeteer.launch({ headless: true});
    page = await browser.newPage();
    await page.goto('https://rezka-ua.tv');
  }
};

// Функция для получения результатов поиска
const getSearchResults = async (query) => {
  try {
    await initializeBrowser();

    // Очищаем поле и вводим новый запрос
    await page.evaluate(() => {
      document.querySelector('#search-field').value = '';
    });
    await page.type('#search-field', query);

    // Ожидаем появления результатов поиска
    await page.waitForSelector('#search-results', { visible: true});

    // Извлекаем результаты фильмов
    const items = await page.evaluate(() => {
      const results = [];
      const elements = document.querySelectorAll('#search-results .b-search__section_list li');
      
      elements.forEach(element => {
        const link = element.querySelector('a');
        const title = link ? link.querySelector('.enty')?.textContent.trim() : null;
        const url = link ? link.href : null;
        if (title && url) {
          results.push({ title, url });
        }
      });

      return results;
    });

    // Извлекаем ссылку на "Смотреть все результаты"
    const seeAll = await page.$('.b-search__live_all');
    let seeAllData = null;
    if (seeAll) {
      const linkHref = await page.evaluate(el => el.href, seeAll);
      const linkText = await page.evaluate(el => el.textContent.trim(), seeAll);
      seeAllData = { url: linkHref, text: linkText };
    }

    return { items, seeAll: seeAllData };
  } catch (error) {
    console.error('Ошибка при получении данных с сайта:', error);
    throw new Error('Ошибка при получении данных');
  }
};

// Создаем сервер
const server = http.createServer(async (req, res) => {
  const queryObject = url.parse(req.url, true).query;

  if (req.url.startsWith('/search')) {
    const query = queryObject.query || '';

    try {
      const decodedQuery = decodeURIComponent(query);  // Декодируем кириллицу в запросе
      const results = await getSearchResults(decodedQuery);

      // Устанавливаем заголовок с правильной кодировкой
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify(results));
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Произошла ошибка при поиске: ' + error.message);
    }
  } else if (req.url === '/') {
    // Отправляем основной HTML-файл
    fs.readFile('index.html', 'utf8', (err, data) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Ошибка при загрузке страницы');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(data);
    });
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Страница не найдена');
  }
});

// Запускаем сервер на порту 3000
server.listen(3000, async () => {
  await initializeBrowser(); // Инициализируем браузер при запуске сервера
  console.log('Сервер запущен на http://localhost:3000');
});

// Закрываем браузер при завершении работы приложения
process.on('exit', async () => {
  if (browser) {
    await browser.close();
  }
});