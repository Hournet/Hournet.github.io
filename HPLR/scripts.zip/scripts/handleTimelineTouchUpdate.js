export function handleTimelineTouchUpdate(touch, isScrubbing, timelineContainer, video,  touchScrubbingPosition) {
    if (!isScrubbing) return;
  
    const rect = timelineContainer.getBoundingClientRect();
    const touchX = touch.clientX - rect.x;
    const percent = Math.min(Math.max(0, touchX), rect.width) / rect.width;
  
    touchScrubbingPosition = percent * video.duration;
  
    // thumbnailImg.src = `assets/previewImgs/preview${Math.max(
    //   1,
    //   Math.floor((percent * video.duration) / 10)
    // )}.jpg`;
  
    timelineContainer.style.setProperty("--progress-position", percent);
    return touchScrubbingPosition;
  }