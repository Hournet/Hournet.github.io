export function toggleScrubbing(e,timelineContainer,isScrubbing, videoContainer, video) {
    const rect = timelineContainer.getBoundingClientRect();
    const percent = Math.min(Math.max(0, e.x - rect.x), rect.width) / rect.width;
    isScrubbing = (e.buttons & 1) === 1;
    videoContainer.classList.toggle("scrubbing", isScrubbing);
  
    if (isScrubbing) {
      if (video.playbackRate !== 0) {
        video.pause();
      }
    } else {
      video.currentTime = percent * video.duration;
      if (video.playbackRate !== 0) {
        video.play();
      }
    }
  
   touchScrubbingPosition = handleTimelineTouchUpdate(e,isScrubbing, timelineContainer, video, touchScrubbingPosition);
    // handleTimelineUpdate(e)
  }