//drag timeline TouchScreen

export function dragTimelineTouchScreen(document, timelineTouch, touchInProgress, isScrubbing, touchScrubbingPosition, video, timelineContainer) {
    timelineTouch.addEventListener("touchstart", (e) => {
      document.querySelector("body").style.overscrollBehavior = "none";
      isScrubbing = true;
      touchInProgress = true;
      touchScrubbingPosition = video.currentTime;
    });
  
    timelineTouch.addEventListener("touchmove", (e) => {
      if (!touchInProgress) return;
      touchScrubbingPosition = handleTimelineTouchUpdate(e.touches[0], isScrubbing, timelineContainer, video, touchScrubbingPosition);
    });
  
    timelineTouch.addEventListener("touchend", () => {
      document.querySelector("body").style.overscrollBehavior = "auto";
      if (touchInProgress) {
        touchInProgress = false;
        video.currentTime = touchScrubbingPosition;
        touchScrubbingPosition = 0;
      }
    });
  }
  